//
//  View.m
//  Touch
//
//  Created by NYU User on 10/28/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "View.h"


@implementation View


- (id) initWithFrame: (CGRect) frame {
	if ((self = [super initWithFrame: frame]) != nil) {
		// Initialization code
		self.backgroundColor = [UIColor whiteColor];
		
		CGRect f = CGRectMake(0, 0, 80, 40);
		view = [[UIView alloc] initWithFrame: f];
		view.backgroundColor = [UIColor blackColor];
		[self addSubview: view];
	}
	return self;
}

- (void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event {
	if (touches.count > 0) {
        static bool toggleColor = false;
		[UIView beginAnimations: nil context: NULL];
        
        //Describe the animation itself.
        [UIView setAnimationDuration: 1.0];	//in seconds; default is 0.2
        [UIView setAnimationCurve: UIViewAnimationCurveEaseInOut];
        [UIView setAnimationRepeatCount: 1.0];	//The default is 1.0.
        
        //Describe what the animation should do.
//        view.center = [[touches anyObject] locationInView: self];
  //      if(!toggleColor)
    //        view.backgroundColor = [UIColor greenColor];
      //  else
        //    view.backgroundColor = [UIColor blackColor];
       // view.alpha = toggleColor;
       // toggleColor= !toggleColor;
        CGPoint p = [[touches anyObject] locationInView: self];
		CGFloat h = self.bounds.size.height;
        
		view.backgroundColor = [UIColor
                                colorWithRed: 0.0
                                green: p.y / h		//green near the bottom
                                blue: (h - p.y) / h	//blue near the top
                                alpha: 1.0
                                ];
        view.center = p;
        view.transform = CGAffineTransformConcat(
                                                 CGAffineTransformMakeRotation(90 * M_PI / 180),
                                                 CGAffineTransformMakeScale(1, 2)
                                                 );
		[UIView commitAnimations];
	}
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void) drawRect: (CGRect) rect {
    // Drawing code
}
*/

- (void) dealloc {
	[view release];
	[super dealloc];
}


@end
